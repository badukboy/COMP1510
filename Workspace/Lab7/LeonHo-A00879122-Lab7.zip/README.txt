HO_LEON_A00879122_SET1B_Lab7

Name: Leon Ho
StudentID: A00879122
Set: 1B
Lab: 7

This submission has bat files to run each and every indivdual programs.

Class files can be found in 
/submission/

Soruce files can be found in 
/source/

Q1 - Rock Paper Scissiors
	All done, everything works fine.


Q2 - Date Validation
	All done everything works fine.


Q3 - Processing Grades
	All done everything works fine.


Q4 - Finding Maximum and minimum values
	All done everything works fine. 