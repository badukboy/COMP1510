[Leon Ho], [A00879122], [B], [March 29 2014]

This assignment is [100]% complete.


------------------------
Question one (PalindromeTester) status:

Complete 
Everything works fine

------------------------
Question two (RockPaperScissors) status:

Complete 
Everything works fine

------------------------
Question three (TestStudent and supporting classes) status:

Complete 
Everything works fine

------------------------
Question four (TestCourse and supporting classes) status:

Complete 
Everything works fine

------------------------
